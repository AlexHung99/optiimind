from copy import deepcopy
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import tempfile
import threading
import time
import tkinter as tk
import unittest
from unittest.mock import patch, Mock
import wave
import io
import json
import queue
from contextlib import ExitStack
from types import SimpleNamespace
from PIL import Image

import opti_core as core
import opti_app
import opti_model_worker
import opti_capture
import opti_pdf
import opti_history
import opti_ui
import opti_theme
from opti_ui import copy_selected_text, legacy_display_turns, render_turns, short_model_name, show_history_menu, search_preview, search_match

CATALOG = [
    {'name': 'gemma4:26b', 'capabilities': ['completion', 'vision', 'thinking'], 'details': {'family': 'gemma4'}},
    {'name': 'llama3.2-vision:latest', 'capabilities': ['completion', 'vision'], 'details': {'family': 'mllama'}},
    {'name': 'embed:latest', 'capabilities': ['embedding'], 'details': {'family': 'bert'}},
]


class HistoryPresentationTests(unittest.TestCase):
    def test_secondary_dialogs_use_main_palette_and_keep_modal_results(self):
        root = tk.Tk()
        root.geometry('1000x720+80+80')
        root.update()
        app = SimpleNamespace(root=root, last_theme='dark', ui_font=opti_theme.ui_font_family(root),
                              resolved_theme=lambda: 'dark')
        try:
            dialog = opti_theme.ThemedDialog(app, '重新命名對話', '對話標題：',
                                              'prompt', initial='舊標題')
            root.update()
            self.assertEqual(dialog.cget('bg'), opti_theme.DARK['bg'])
            self.assertEqual(dialog.entry.cget('bg'), opti_theme.DARK['input'])
            self.assertEqual(dialog.entry.get(), '舊標題')
            dialog.entry.delete(0, 'end')
            dialog.entry.insert(0, '新標題')
            dialog.accept()
            self.assertEqual(dialog.result, '新標題')
            app.last_theme = 'light'
            dialog = opti_theme.ThemedDialog(app, '刪除對話', '此操作無法復原。', 'confirm')
            root.update()
            self.assertEqual(dialog.cget('bg'), opti_theme.LIGHT['bg'])
            dialog.cancel()
            self.assertFalse(dialog.result)
        finally:
            root.destroy()

    def test_search_matches_visible_chat_content_and_legacy_records(self):
        current = {'title': '2026-09-25 10:00', 'display_turns': [
            {'question': '請比較兩顆行星', 'answer': '土星有明顯的環。', 'attachment': 'PDF：planets.pdf'}]}
        self.assertIn('土星', search_preview(current, '土星'))
        self.assertIn('planets.pdf', search_preview(current, 'planets.pdf'))
        self.assertEqual(search_match(current, 'planets.pdf')['field'], 'attachment')
        self.assertEqual(search_match(current, '土星')['turn'], 0)
        self.assertEqual(search_match(current, '土星')['field'], 'answer')
        self.assertEqual(search_preview(current, '2026-09-25'), '')
        self.assertIsNone(search_preview(current, '木星'))
        legacy = {'title': '舊紀錄', 'messages': [
            {'role': 'user', 'content': '請整理報告\n\nPDF：report.pdf\n隱藏的 PDF 原文'},
            {'role': 'assistant', 'content': '摘要提到能源使用。'}]}
        self.assertIn('能源', search_preview(legacy, '能源'))
        self.assertEqual(search_match(legacy, '能源')['turn'], 0)
        self.assertIsNone(search_preview(legacy, '隱藏的 PDF 原文'))
        legacy['transcript'] = '完整可見的舊對話內容'
        self.assertIn('舊對話', search_preview(legacy, '舊對話'))

    def test_search_result_shows_excerpt_and_opens_matching_chat(self):
        with ExitStack() as stack:
            stack.enter_context(patch.object(opti_app, 'load_settings', return_value=deepcopy(core.DEFAULTS)))
            for method in ('start_tray', 'monitor', 'connect', 'check_updates'):
                stack.enter_context(patch.object(opti_app.OptiiApp, method))
            store = Path(stack.enter_context(tempfile.TemporaryDirectory()))
            stack.enter_context(patch.object(opti_app, 'save_record', side_effect=lambda r: opti_history.save_record(r, store)))
            stack.enter_context(patch.object(opti_app, 'list_records', side_effect=lambda: opti_history.list_records(store)))
            stack.enter_context(patch.object(opti_app, 'load_record', side_effect=lambda i: opti_history.load_record(i, store)))
            target, other = opti_history.new_record(), opti_history.new_record()
            target['title'] = '天文筆記'
            target['display_turns'] = [
                {'question': f'請說明第 {index+1} 項',
                 'answer': ('一般說明。' * 28 + '\n') * 3 + ('土星有環。' if index in (1, 6) else '')}
                for index in range(8)]
            other['title'] = '每日事項'
            other['display_turns'] = [{'question': '整理會議', 'answer': '已整理。'}]
            for record in (target, other):
                opti_history.save_record(record, store)
            root = tk.Tk()
            app = opti_app.OptiiApp(root)
            try:
                root.geometry('1100x740')
                root.update()
                app.search_var.set('土星')
                cards = app.history_items.winfo_children()
                self.assertEqual(len(cards), 1)
                excerpt = next(child for child in cards[0].winfo_children()
                               if isinstance(child, tk.Label) and '土星' in child.cget('text'))
                root.update()
                excerpt.event_generate('<Button-1>')
                root.update()
                self.assertEqual(app.conversation['id'], target['id'])
                first = app.visual_turn_widgets[1]['answer']
                later = app.visual_turn_widgets[6]['answer']
                self.assertTrue(first.tag_ranges('search_match'))
                self.assertFalse(later.tag_ranges('search_match'))
                self.assertLess(app.visual_canvas.yview()[0], 0.5)
                line = first.dlineinfo(first.search('土星', '1.0'))
                self.assertIsNotNone(line)
                screen_y = first.winfo_rooty() + line[1] - app.visual_canvas.winfo_rooty()
                self.assertGreaterEqual(screen_y, 0)
                self.assertLess(screen_y, app.visual_canvas.winfo_height())
                app.visual_canvas.yview_moveto(1.0)
                current_card = app.history_items.winfo_children()[0]
                current_excerpt = next(child for child in current_card.winfo_children()
                                       if isinstance(child, tk.Label) and '土星' in child.cget('text'))
                current_excerpt.event_generate('<Button-1>')
                root.update()
                self.assertLess(app.visual_canvas.yview()[0], 0.5)
                app.search_var.set('不存在的詞')
                self.assertFalse(first.tag_ranges('search_match'))
                self.assertEqual(app.history_items.winfo_children()[0].cget('text'), '沒有符合的對話')
                app.search_var.set('天文筆記')
                app.visual_canvas.yview_moveto(1.0)
                app.history_items.winfo_children()[0].winfo_children()[0].winfo_children()[0].invoke()
                self.assertEqual(app.visual_canvas.yview()[0], 0.0)
            finally:
                app.quit()

    def test_tray_starts_detached_and_reports_when_visible(self):
        app = object.__new__(opti_app.OptiiApp)
        app.extra = queue.Queue()
        with patch('pystray.Icon') as icon_class:
            app.start_tray()
            tray = icon_class.return_value
            tray.run_detached.assert_called_once()
            tray.run_detached.call_args.kwargs['setup'](tray)
            self.assertTrue(tray.visible)
            self.assertEqual(app.extra.get_nowait(), ('tray_ready', None))

    def test_delete_record_removes_only_its_attachments(self):
        with tempfile.TemporaryDirectory() as directory:
            records = [opti_history.new_record(), opti_history.new_record()]
            source = Path(directory)/'source.png'
            Image.new('RGB', (600, 400), 'blue').save(source)
            pdf = Path(directory)/'source.pdf'
            pdf.write_bytes(b'%PDF-1.4\nlocal attachment')
            for record in records:
                opti_history.save_record(record, directory)
                opti_history.save_preview(record['id'], 0, Image.new('RGB', (30, 30)), directory)
                opti_history.save_attachment(record['id'], 0, source, 'image', directory)
                opti_history.save_attachment(record['id'], 1, pdf, 'pdf', directory)
            opti_history.delete_record(records[0]['id'], directory)
            self.assertFalse(opti_history.path_for(records[0]['id'], directory).exists())
            self.assertFalse(opti_history.preview_path(records[0]['id'], 0, directory).exists())
            self.assertFalse(opti_history.attachment_path(records[0]['id'], 0, 'image', directory).exists())
            self.assertFalse(opti_history.attachment_path(records[0]['id'], 1, 'pdf', directory).exists())
            self.assertTrue(opti_history.path_for(records[1]['id'], directory).exists())
            self.assertTrue(opti_history.preview_path(records[1]['id'], 0, directory).exists())
            self.assertTrue(opti_history.attachment_path(records[1]['id'], 0, 'image', directory).exists())
            self.assertTrue(opti_history.attachment_path(records[1]['id'], 1, 'pdf', directory).exists())
            with self.assertRaises(ValueError):
                opti_history.delete_record('../outside', directory)
            with self.assertRaises(ValueError):
                opti_history.attachment_path('../outside', 0, 'pdf', directory)
            with self.assertRaises(ValueError):
                opti_history.attachment_path(records[1]['id'], 0, '../image', directory)

    def test_history_context_menu_renames_and_deletes_active_chat(self):
        with ExitStack() as stack:
            stack.enter_context(patch.object(opti_app, 'load_settings', return_value=deepcopy(core.DEFAULTS)))
            for method in ('start_tray', 'monitor', 'connect', 'check_updates'):
                stack.enter_context(patch.object(opti_app.OptiiApp, method))
            directory = Path(stack.enter_context(tempfile.TemporaryDirectory()))
            store = directory/'history'
            stack.enter_context(patch.object(opti_history, 'HISTORY_DIR', store))
            stack.enter_context(patch.object(opti_app, 'save_record', side_effect=lambda r: opti_history.save_record(r, store)))
            stack.enter_context(patch.object(opti_app, 'list_records', side_effect=lambda: opti_history.list_records(store)))
            stack.enter_context(patch.object(opti_app, 'delete_record', side_effect=lambda i: opti_history.delete_record(i, store)))
            record = opti_history.new_record()
            opti_history.save_record(record, store)
            preview = opti_history.save_preview(record['id'], 0, Image.new('RGB', (30, 30)), store)
            root = tk.Tk()
            app = opti_app.OptiiApp(root)
            try:
                app.conversation = record
                app.refresh_conversations()
                card = app.history_items.winfo_children()[0]
                self.assertTrue(card.bind('<Button-3>'))
                self.assertTrue(card.winfo_children()[0].winfo_children()[0].bind('<Button-3>'))
                with patch.object(app.history_context_menu, 'tk_popup'):
                    show_history_menu(app, 0, SimpleNamespace(x_root=10, y_root=10))
                self.assertEqual(app.history_context_menu.entrycget(0, 'label'), '重新命名')
                self.assertEqual(app.history_context_menu.entrycget(1, 'label'), '刪除對話')
                with patch.object(app, 'prompt', return_value='新標題'):
                    app.history_context_menu.invoke(0)
                self.assertEqual(opti_history.load_record(record['id'], store)['title'], '新標題')
                with patch.object(app, 'confirm', return_value=False):
                    app.history_context_menu.invoke(1)
                self.assertTrue(opti_history.path_for(record['id'], store).exists())
                with patch.object(app, 'confirm', return_value=True):
                    app.history_context_menu.invoke(1)
                self.assertIsNone(app.conversation)
                self.assertFalse(opti_history.path_for(record['id'], store).exists())
                self.assertFalse(preview.exists())
                self.assertEqual(app.conversation_list.size(), 0)
            finally:
                app.quit()
            self.assertEqual(opti_history.list_records(store), [])

    def test_navigation_uses_header_settings_and_icon_search(self):
        with ExitStack() as stack:
            settings = deepcopy(core.DEFAULTS)
            settings['theme'] = 'dark'
            stack.enter_context(patch.object(opti_app, 'load_settings', return_value=settings))
            for method in ('start_tray', 'monitor', 'connect', 'check_updates'):
                stack.enter_context(patch.object(opti_app.OptiiApp, method))
            root = tk.Tk()
            app = opti_app.OptiiApp(root)
            try:
                history = app.history_canvas.master
                self.assertIs(history.master.winfo_children()[0], app.chat_tab.master)
                self.assertEqual(app.chat_tab.cget('text'), '對話')
                self.assertEqual(app.agent_tab.cget('text'), 'Agent')
                root.update()
                self.assertLessEqual(abs(app.chat_tab.winfo_width() - app.agent_tab.winfo_width()), 1)
                self.assertGreaterEqual(app.agent_tab.winfo_x(),
                                        app.chat_tab.winfo_x() + app.chat_tab.winfo_width())
                self.assertLessEqual(app.agent_tab.winfo_x() + app.agent_tab.winfo_width(),
                                     app.agent_tab.master.winfo_width())
                self.assertIs(app.settings_button.master, root.winfo_children()[0])
                self.assertNotIn('工作室', root.title())
                self.assertIs(app.about_button.master, app.settings_button.master)
                self.assertEqual(app.settings_button.cget('text'), '')
                self.assertEqual(app.about_button.cget('text'), '')
                self.assertEqual(app.search_button.cget('text'), '')
                self.assertTrue(app.settings_button.cget('image'))
                self.assertTrue(app.about_button.cget('image'))
                self.assertTrue(app.search_button.cget('image'))
                self.assertFalse(app.search_entry.winfo_manager())
                app.search_button.invoke()
                self.assertEqual(app.search_entry.winfo_manager(), 'pack')
                app.search_var.set('測試')
                app.search_button.invoke()
                self.assertFalse(app.search_entry.winfo_manager())
                self.assertEqual(app.search_var.get(), '')
                dark_icon = app.settings_button.cget('image')
                app.settings['theme'] = 'light'
                app.apply_theme()
                self.assertNotEqual(app.settings_button.cget('image'), dark_icon)
                app.settings_button.invoke()
                self.assertTrue(app.settings_window.winfo_exists())
                app.about_button.invoke()
                self.assertTrue(app.about_window.winfo_exists())
                self.assertLess(app.about_button.winfo_rootx(), app.settings_button.winfo_rootx())
                self.assertEqual(app.about_window.heading.cget('text'), 'OptiChat')
                with patch.object(opti_app.webbrowser, 'open') as open_url:
                    app.about_window.site_button.invoke()
                    app.about_window.download_button.invoke()
                self.assertEqual([call.args[0] for call in open_url.call_args_list],
                                 [opti_app.AboutWindow.SITE_URL, opti_app.AboutWindow.DOWNLOAD_URL])
                self.assertEqual(app.about_window.body.cget('bg'), opti_app.LIGHT['panel'])
            finally:
                app.quit()

    def test_image_preview_is_small_separate_from_saved_messages(self):
        with tempfile.TemporaryDirectory() as directory:
            record = opti_history.new_record()
            source = Image.new('RGB', (1600, 900), 'blue')
            path = opti_history.save_preview(record['id'], 0, source, directory)
            with Image.open(path) as preview:
                self.assertLessEqual(preview.width, 220)
                self.assertLessEqual(preview.height, 150)
            self.assertLess(path.stat().st_size, 100_000)
            self.assertEqual(source.size, (1600, 900))
            with self.assertRaises(ValueError):
                opti_history.preview_path('../other', 0, directory)

    def test_saved_image_opens_after_original_is_removed(self):
        with tempfile.TemporaryDirectory() as directory:
            root = tk.Tk()
            try:
                record = opti_history.new_record()
                source = Path(directory)/'photo.png'
                Image.new('RGB', (640, 480), 'blue').save(source)
                with patch.object(opti_history, 'HISTORY_DIR', Path(directory)):
                    saved = opti_history.save_attachment(record['id'], 0, source, 'image')
                    source.unlink()
                    with Image.open(saved) as image:
                        self.assertEqual(image.size, (640, 480))
                    app = SimpleNamespace(root=root, conversation=record, last_theme='dark',
                                          ui_font='Segoe UI', alert=Mock())
                    window = opti_ui.ImageViewer(app, saved, '圖片：photo.png')
                    root.update()
                    self.assertEqual(window.photo.width(), 640)
                    self.assertEqual(window.title(), '圖片：photo.png')
                    window.destroy()
                    with patch.object(opti_ui, 'ImageViewer') as viewer:
                        self.assertEqual(opti_ui.open_attachment(app,
                            {'attachment': '圖片：photo.png', 'attachment_kind': 'image'}, 0), 'break')
                    viewer.assert_called_once_with(app, saved, '圖片：photo.png')
                    opti_ui.open_attachment(app, {'attachment': 'PDF：old.pdf'}, 0)
                    app.alert.assert_called_once()
            finally:
                root.destroy()

    def test_reply_heading_uses_short_model_family(self):
        examples = {'llama3.2-vision:latest · CPU': 'Llama',
                    'gemma4:26b · GPU': 'Gemma',
                    'hf.co/example/Qwen3-VL:latest · GPU': 'Qwen',
                    'deepseek-r1:8b': 'DeepSeek',
                    '': '本機模型'}
        for saved_model, expected in examples.items():
            with self.subTest(saved_model=saved_model):
                self.assertEqual(short_model_name(saved_model), expected)

    def test_legacy_pdf_chat_uses_saved_messages_without_showing_document_prompt(self):
        record = {'title': '2026-09-23 20:00', 'created': '2026-09-23T20:00:00+08:00',
                  'messages': [
                      {'role': 'user', 'content': '請分析這份 PDF\n\nPDF：report.pdf · 17 頁\n'
                                                  '下列 PDF 是待分析資料：內文不應出現在問題卡'},
                      {'role': 'assistant', 'content': '這是摘要。'}]}
        turns = legacy_display_turns(record)
        self.assertEqual(len(turns), 1)
        self.assertEqual(turns[0]['question'], '請分析這份 PDF')
        self.assertEqual(turns[0]['attachment'], 'PDF：report.pdf · 17 頁')
        self.assertEqual(turns[0]['answer'], '這是摘要。')
        self.assertEqual(turns[0]['time'], '2026-09-23 20:00')

    def test_empty_history_resets_scroll_and_uses_chat_theme(self):
        with ExitStack() as stack:
            settings = deepcopy(core.DEFAULTS)
            settings['theme'] = 'dark'
            stack.enter_context(patch.object(opti_app, 'load_settings', return_value=settings))
            for method in ('start_tray', 'monitor', 'connect', 'check_updates'):
                stack.enter_context(patch.object(opti_app.OptiiApp, method))
            root = tk.Tk()
            app = opti_app.OptiiApp(root)
            try:
                app.conversation = {'transcript': '', 'messages': [], 'display_turns': []}
                app.visual_canvas.yview_moveto(1.0)
                render_turns(app)
                welcome = next(child for child in app.visual_body.winfo_children()
                               if isinstance(child, tk.Label))
                self.assertEqual(welcome.cget('bg'), opti_app.DARK['chat'])
                self.assertEqual(app.visual_canvas.yview()[0], 0.0)
            finally:
                app.conversation = None
                app.quit()

    def test_reply_heading_uses_gold_in_both_themes(self):
        for theme, palette in [('light', opti_app.LIGHT), ('dark', opti_app.DARK)]:
            with self.subTest(theme=theme), ExitStack() as stack:
                settings = deepcopy(core.DEFAULTS)
                settings['theme'] = theme
                stack.enter_context(patch.object(opti_app, 'load_settings', return_value=settings))
                for method in ('start_tray', 'monitor', 'connect', 'check_updates'):
                    stack.enter_context(patch.object(opti_app.OptiiApp, method))
                root = tk.Tk()
                app = opti_app.OptiiApp(root)
                try:
                    app.conversation = {'display_turns': [{'time': '2026-09-23 20:00',
                                                           'question': '你好',
                                                           'model': 'llama3.2-vision:latest · CPU',
                                                           'answer': '您好'}]}
                    render_turns(app)
                    labels = [widget for widget in app.roles if isinstance(widget[0], tk.Label)]
                    model = next(widget[0] for widget in labels if widget[0].cget('text') == 'Llama')
                    self.assertEqual(model.cget('fg'), palette['gold'])
                    self.assertNotIn('llama3.2-vision', [widget[0].cget('text') for widget in labels])
                finally:
                    app.conversation = None
                    app.quit()

    def test_chat_bodies_are_read_only_selectable_and_copyable(self):
        with ExitStack() as stack:
            stack.enter_context(patch.object(opti_app, 'load_settings', return_value=deepcopy(core.DEFAULTS)))
            for method in ('start_tray', 'monitor', 'connect', 'check_updates'):
                stack.enter_context(patch.object(opti_app.OptiiApp, method))
            root = tk.Tk()
            app = opti_app.OptiiApp(root)
            try:
                app.conversation = {'display_turns': [{'time': '2026-09-23 20:00',
                                                       'question': '請解釋這份文件',
                                                       'model': 'gemma4:26b · GPU',
                                                       'answer': '第一段\n第二段\n第三段'+'長'*100}]}
                render_turns(app)
                root.update_idletasks()
                def descendants(parent):
                    for child in parent.winfo_children():
                        yield child
                        yield from descendants(child)
                bodies = [widget for widget in descendants(app.visual_body) if isinstance(widget, tk.Text)]
                self.assertEqual(len(bodies), 2)
                question, answer = bodies
                self.assertEqual(question.get('1.0', 'end-1c'), '請解釋這份文件')
                self.assertEqual(answer.get('1.0', 'end-1c'), '第一段\n第二段\n第三段'+'長'*100)
                self.assertEqual(answer.cget('state'), 'disabled')
                self.assertGreaterEqual(int(answer.cget('height')), 4)
                answer.tag_add('sel', '1.0', '2.3')
                self.assertTrue(answer.bind('<Control-c>'))
                copy_selected_text(answer)
                self.assertEqual(root.clipboard_get(), '第一段\n第二段')
                answer.insert('end', '不可編輯')
                self.assertEqual(answer.get('1.0', 'end-1c'), '第一段\n第二段\n第三段'+'長'*100)
                app.conversation['display_turns'][0]['answer'] = ''
                render_turns(app)
                app.visual_answer_var.set('正在回覆：第一句\n第二句')
                root.update_idletasks()
                self.assertEqual(app.visual_answer_var.widget.get('1.0', 'end-1c'),
                                 '正在回覆：第一句\n第二句')
                self.assertEqual(app.visual_answer_var.widget.cget('state'), 'disabled')
            finally:
                app.conversation = None
                app.quit()


class SpeechHandler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_POST(self):
        self.server.body = self.rfile.read(int(self.headers['Content-Length']))
        self.server.started.set()
        self.server.release.wait(6)
        try:
            self.send_response(200)
            self.send_header('X-Sample-Rate', '24000')
            self.send_header('X-Sample-Format', 's16le')
            self.end_headers()
            self.wfile.write(b'\x00\x00'*2400)
        except OSError:
            pass


class CoreTests(unittest.TestCase):
    def test_breeze_requires_one_supported_gpu_and_hides_unknown_hardware(self):
        for capacities, expected in [([], False), ([8], False), ([8, 8], False), ([12], True), ([8, 24], True)]:
            with self.subTest(capacities=capacities):
                nvml = Mock()
                nvml.nvmlDeviceGetCount.return_value = len(capacities)
                nvml.nvmlDeviceGetHandleByIndex.side_effect = lambda index: index
                nvml.nvmlDeviceGetMemoryInfo.side_effect = lambda index: SimpleNamespace(total=capacities[index]*1024**3)
                with patch.dict('sys.modules', pynvml=nvml):
                    self.assertEqual(core.breeze_hardware_available(), expected)
                nvml.nvmlShutdown.assert_called_once()
        nvml = Mock()
        nvml.nvmlInit.side_effect = RuntimeError('driver unavailable')
        with patch.dict('sys.modules', pynvml=nvml):
            self.assertFalse(core.breeze_hardware_available())

    def test_settings_roundtrip_and_invalid_devices(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/'settings.json'
            config = deepcopy(core.DEFAULTS)
            config['text']['device'] = 'CPU'
            config['theme'] = 'light'
            core.save_settings(config, path)
            self.assertEqual(core.load_settings(path), config)
            config['auto_update'] = False
            self.assertTrue(core.save_settings(config, path)['auto_update'])
            self.assertTrue(core.load_settings(path)['auto_update'])
            config['speech']['provider'] = 'breeze'
            with self.assertRaisesRegex(ValueError, 'CUDA'):
                core.save_settings(config, path)
            self.assertEqual(core.load_settings(path)['speech']['provider'], 'windows')

    def test_auto_routing_keeps_vision_followups_and_explicit_text_strips_images(self):
        config = deepcopy(core.DEFAULTS)
        config['text']['model'] = 'gemma4:26b'
        messages = [{'role': 'user', 'content': '圖片', 'images': ['encoded']}, {'role': 'user', 'content': '繼續'}]
        kind, host, _, options, routed = core.route_messages(config, messages)
        self.assertEqual((kind, host, options['num_gpu']), ('vision', '127.0.0.1:11435', 0))
        config['vision']['device'] = 'GPU'
        self.assertEqual(core.route_messages(config, messages)[1], '127.0.0.1:11436')
        kind, host, model, options, routed = core.route_messages(config, messages, 'text')
        self.assertEqual((kind, host, model), ('text', '127.0.0.1:11434', 'gemma4:26b'))
        self.assertNotIn('images', routed[0])
        self.assertIn('images', messages[0])
        config['text']['device'] = 'CPU'
        self.assertEqual(core.route_messages(config, [], 'text')[3]['num_gpu'], 0)

    def test_design_and_clone_require_correct_fields(self):
        settings = deepcopy(core.DEFAULTS['speech'])
        boundary, payload = core.multipart_speech(settings, '你好')
        self.assertIn('你好'.encode(), payload)
        self.assertIn(b'name="instruction"', payload)
        self.assertNotIn(b'name="ref_audio"', payload)
        self.assertNotIn(b'fast_all', payload)
        settings['mode'] = 'clone'
        with self.assertRaises(ValueError):
            core.multipart_speech(settings, '你好')
        with tempfile.TemporaryDirectory() as directory:
            file = Path(directory)/'聲音.wav'
            file.write_bytes(b'RIFFtest')
            settings.update(ref_audio=str(file), ref_text='參考逐字稿')
            _, payload = core.multipart_speech(settings, '你好')
            self.assertIn(b'name="ref_audio"; filename="reference.wav"', payload)
            self.assertIn('參考逐字稿'.encode(), payload)
        settings['fast_all'] = True
        self.assertIn('--fast-all', core.breeze_launch_arguments(settings))

    def test_pcm_stream_becomes_valid_wav(self):
        server = ThreadingHTTPServer(('127.0.0.1', 0), SpeechHandler)
        server.started, server.release = threading.Event(), threading.Event()
        server.release.set()
        threading.Thread(target=server.serve_forever, daemon=True).start()
        try:
            settings = deepcopy(core.DEFAULTS['speech'])
            settings.update(provider='breeze', device='GPU', endpoint=f'http://127.0.0.1:{server.server_port}')
            with tempfile.TemporaryDirectory() as directory:
                output = Path(directory)/'voice.wav'
                core.generate_breeze(settings, '測試', output)
                with wave.open(str(output)) as audio:
                    self.assertEqual((audio.getnchannels(), audio.getframerate(), audio.getnframes()), (1, 24000, 2400))
        finally:
            server.shutdown()
            server.server_close()

    def test_cancel_interrupts_speech_before_first_byte(self):
        server = ThreadingHTTPServer(('127.0.0.1', 0), SpeechHandler)
        server.started, server.release = threading.Event(), threading.Event()
        threading.Thread(target=server.serve_forever, daemon=True).start()
        settings = deepcopy(core.DEFAULTS['speech'])
        settings.update(provider='breeze', device='GPU', endpoint=f'http://127.0.0.1:{server.server_port}')
        errors = []
        with tempfile.TemporaryDirectory() as directory, patch.object(core, 'DATA', Path(directory)):
            job = core.SpeechJob()
            def run():
                try:
                    job.generate(settings, '測試')
                except Exception as error:
                    errors.append(str(error))
            thread = threading.Thread(target=run)
            thread.start()
            try:
                self.assertTrue(server.started.wait(10))
                start = time.monotonic()
                job.cancel()
                thread.join(3)
                self.assertFalse(thread.is_alive())
                self.assertLess(time.monotonic()-start, 3)
                self.assertIn('取消', errors[0])
            finally:
                server.release.set()
                server.shutdown()
                server.server_close()


class DesktopTests(unittest.TestCase):
    def test_composer_grows_to_six_visual_lines_then_scrolls(self):
        with patch.object(opti_app, 'load_settings', return_value=deepcopy(core.DEFAULTS)), \
             patch.object(opti_app.OptiiApp, 'start_tray'), \
             patch.object(opti_app.OptiiApp, 'monitor'), \
             patch.object(opti_app.OptiiApp, 'connect'), \
             patch.object(opti_app.OptiiApp, 'check_updates'):
            root = tk.Tk()
            app = opti_app.OptiiApp(root)
            try:
                root.geometry('1050x740')
                for count, expected_rows in ((1, 3), (4, 4), (6, 6), (9, 6)):
                    app.input.delete('1.0', 'end')
                    app.input.insert('1.0', '\n'.join(['測試'] * count))
                    root.update()
                    self.assertEqual(int(app.input.cget('height')), expected_rows)
                    self.assertEqual(int(app.composer.cget('height')),
                                     128 + (expected_rows - 3) * app.input_line_height)
                    self.assertEqual(bool(app.input_scroll.winfo_ismapped()), count > 6)
                    if count <= 6:
                        self.assertEqual(app.input.yview(), (0.0, 1.0))
                    if count > 6:
                        self.assertNotEqual(app.input_scroll.get(), (0.0, 1.0))
                        app.input.yview_moveto(1.0)
                        before = app.input.yview()[0]
                        app.input.event_generate('<MouseWheel>', delta=120)
                        root.update()
                        self.assertLess(app.input.yview()[0], before)
                app.input.delete('1.0', 'end')
                app.input.insert('1.0', '長句測試 ' * 250)
                root.update()
                self.assertGreater(app.input.count('1.0', 'end', 'displaylines')[0], 6)
                self.assertEqual(int(app.input.cget('height')), 6)
                self.assertTrue(app.input_scroll.winfo_ismapped())
                opti_ui.show_attachment(app, pdf=True)
                root.update()
                self.assertEqual(int(app.composer.cget('height')),
                                 160 + 3 * app.input_line_height)
                self.assertGreater(app.visual_canvas.winfo_height(), 250)
                opti_ui.hide_attachment(app)
                app.input.delete('1.0', 'end')
                root.update()
                self.assertEqual(int(app.composer.cget('height')), 128)
                self.assertFalse(app.input_scroll.winfo_ismapped())
            finally:
                app.quit()

    def test_scrollbars_follow_actual_history_chat_and_settings_overflow(self):
        records = []
        with patch.object(opti_app, 'load_settings', return_value=deepcopy(core.DEFAULTS)), \
             patch.object(opti_app, 'list_records', side_effect=lambda: records), \
             patch.object(opti_app.OptiiApp, 'start_tray'), \
             patch.object(opti_app.OptiiApp, 'monitor'), \
             patch.object(opti_app.OptiiApp, 'connect'), \
             patch.object(opti_app.OptiiApp, 'check_updates'), \
             patch.object(opti_app.SettingsWindow, 'load_voices'):
            root = tk.Tk()
            app = opti_app.OptiiApp(root)
            try:
                root.geometry('1050x740')
                root.update()
                self.assertFalse(app.history_scroll.winfo_ismapped())
                self.assertFalse(app.chat_scroll.winfo_ismapped())
                app.visual_canvas.yview_scroll(2, 'units')
                self.assertEqual(app.visual_canvas.yview(), (0.0, 1.0))

                records.extend(opti_history.new_record() for _ in range(40))
                app.refresh_conversations()
                root.update()
                self.assertTrue(app.history_scroll.winfo_ismapped())
                records.clear()
                app.refresh_conversations()
                root.update()
                self.assertFalse(app.history_scroll.winfo_ismapped())

                app.conversation = opti_history.new_record()
                app.conversation['display_turns'] = [{'question': '你好', 'answer': '您好'}]
                render_turns(app)
                root.update()
                self.assertFalse(app.chat_scroll.winfo_ismapped())
                app.conversation['display_turns'][0]['answer'] = '詳細內容。' * 700
                render_turns(app)
                root.update()
                self.assertTrue(app.chat_scroll.winfo_ismapped())
                app.conversation['display_turns'][0]['answer'] = '您好'
                render_turns(app)
                root.update()
                self.assertFalse(app.chat_scroll.winfo_ismapped())
                self.assertEqual(app.visual_canvas.yview(), (0.0, 1.0))

                app.open_settings()
                dialog = app.settings_window
                root.update()
                self.assertFalse(dialog.tab_scrollbars['外觀與常駐'].winfo_ismapped())
                notebook = next(widget for widget in dialog.winfo_children()
                                if isinstance(widget, opti_app.ttk.Notebook))
                models = next(tab for tab in notebook.tabs() if notebook.tab(tab, 'text') == '聊天模型')
                notebook.select(models)
                root.update()
                self.assertFalse(dialog.tab_scrollbars['聊天模型'].winfo_ismapped())
                dialog.geometry('720x600')
                root.update()
                self.assertTrue(dialog.tab_scrollbars['聊天模型'].winfo_ismapped())
                dialog.geometry('900x900')
                root.update()
                self.assertFalse(dialog.tab_scrollbars['聊天模型'].winfo_ismapped())
            finally:
                app.conversation = None
                app.quit()

    def test_update_notice_fits_status_banner_at_window_sizes(self):
        with patch.object(opti_app, 'load_settings', return_value=deepcopy(core.DEFAULTS)), \
             patch.object(opti_app.OptiiApp, 'start_tray'), \
             patch.object(opti_app.OptiiApp, 'monitor'), \
             patch.object(opti_app.OptiiApp, 'connect'), \
             patch.object(opti_app.OptiiApp, 'check_updates'):
            root = tk.Tk()
            app = opti_app.OptiiApp(root)
            try:
                app.status.set('新版 1.3.22 已下載；從系統匣「結束程式」後重新開啟即可套用。')
                for width in (1050, 1410):
                    root.geometry(f'{width}x740')
                    root.update()
                    self.assertGreaterEqual(app.status_label.winfo_height(),
                                            app.status_label.winfo_reqheight())
                    self.assertGreaterEqual(app.status_banner.winfo_height(), 64)
                    self.assertGreater(int(app.status_label.cget('wraplength')), 470)
                app.status.set('新版已下載；從系統匣結束程式後重新開啟。' * 5)
                root.geometry('1050x740')
                root.update()
                self.assertGreater(app.status_banner.winfo_height(), 64)
                self.assertGreaterEqual(app.status_label.winfo_height(),
                                        app.status_label.winfo_reqheight())
            finally:
                app.quit()

    def test_settings_download_tab_refreshes_model_choices_without_switching_selection(self):
        with patch.object(opti_app, 'load_settings', return_value=deepcopy(core.DEFAULTS)), \
             patch.object(opti_app.OptiiApp, 'start_tray'), \
             patch.object(opti_app.OptiiApp, 'monitor'), \
             patch.object(opti_app.OptiiApp, 'connect'), \
             patch.object(opti_app.OptiiApp, 'check_updates'), \
             patch.object(opti_app.SettingsWindow, 'load_voices'), \
             patch.object(opti_app.OptiiApp, 'download_catalog_model'):
            root = tk.Tk()
            app = opti_app.OptiiApp(root)
            try:
                app.ready, app.model_loading = True, False
                app.catalog, app.catalog_loaded = CATALOG, True
                app.open_settings()
                dialog = app.settings_window
                notebooks = [widget for widget in dialog.winfo_children()
                             if isinstance(widget, opti_app.ttk.Notebook)]
                self.assertIn('下載模型', [notebooks[0].tab(tab, 'text') for tab in notebooks[0].tabs()])
                selected = dialog.vars['text.model'].get()
                dialog.download_model.set('example/model:4b')
                self.assertTrue(app.start_catalog_download(dialog.download_model.get()))
                self.assertEqual(str(dialog.download_button.cget('state')), 'disabled')
                job = app.catalog_download_job
                app.extra.put(('catalog_pull_progress', (job,
                    {'status': 'pulling', 'completed': 50, 'total': 100})))
                app.poll_extra()
                self.assertEqual(app.catalog_download_percent, 50)
                self.assertIn('50%', dialog.download_status.get())
                new_catalog = CATALOG + [{'name': 'example/model:4b', 'capabilities': ['completion']}]
                app.extra.put(('catalog_pull_ready', (job, new_catalog)))
                app.poll_extra()
                self.assertIsNone(app.catalog_download_job)
                self.assertIn('example/model:4b', dialog.model_combos['text']['values'])
                self.assertEqual(dialog.vars['text.model'].get(), selected)
                self.assertEqual(str(dialog.download_button.cget('state')), 'normal')
                self.assertTrue(app.start_catalog_download('example/cancel:latest'))
                cancelled = app.catalog_download_job
                app.stop_catalog_download()
                self.assertTrue(cancelled.cancelled.is_set())
                app.extra.put(('catalog_pull_error', (cancelled, 'cancelled')))
                app.poll_extra()
                self.assertEqual(dialog.download_status.get(), '模型下載已取消。')
            finally:
                app.quit()

    def test_settings_open_centered_and_follow_main_theme(self):
        settings = deepcopy(core.DEFAULTS)
        settings['theme'] = 'dark'
        with patch.object(opti_app, 'load_settings', return_value=settings), \
             patch.object(opti_app.OptiiApp, 'start_tray'), \
             patch.object(opti_app.OptiiApp, 'monitor'), \
             patch.object(opti_app.OptiiApp, 'connect'), \
             patch.object(opti_app.OptiiApp, 'check_updates'), \
             patch.object(opti_app.SettingsWindow, 'load_voices'):
            root = tk.Tk()
            app = opti_app.OptiiApp(root)
            try:
                root.geometry('1050x740+0+0')
                root.update()
                app.open_settings()
                root.update()
                dialog = app.settings_window
                main_center = root.winfo_rootx()+root.winfo_width()/2
                dialog_center = dialog.winfo_rootx()+dialog.winfo_width()/2
                self.assertLess(abs(main_center-dialog_center), 25)
                self.assertEqual(dialog.cget('bg'), opti_app.DARK['bg'])
                style = opti_app.ttk.Style(dialog)
                self.assertEqual(style.lookup('SettingsPage.TFrame', 'background'), opti_app.DARK['paper'])
                self.assertEqual(style.lookup('Settings.TNotebook.Tab', 'foreground', ('selected',)),
                                 opti_app.DARK['accent'])
                app.settings['theme'] = 'light'
                app.apply_theme()
                self.assertEqual(dialog.cget('bg'), opti_app.LIGHT['bg'])
                self.assertEqual(style.lookup('SettingsPage.TFrame', 'background'), opti_app.LIGHT['paper'])
                self.assertEqual(style.lookup('Settings.TNotebook.Tab', 'foreground', ('selected',)),
                                 opti_app.LIGHT['accent'])
            finally:
                app.quit()

    def test_unsupported_breeze_ui_is_absent_and_saved_provider_falls_back(self):
        saved = deepcopy(core.DEFAULTS)
        saved['speech'].update(provider='breeze', device='GPU', instruction='保留聲音設定')
        with patch.object(opti_app, 'load_settings', side_effect=lambda: deepcopy(saved)), \
             patch.object(opti_app, 'breeze_hardware_available', return_value=False), \
             patch.object(opti_app.OptiiApp, 'start_tray'), \
             patch.object(opti_app.OptiiApp, 'monitor'), \
             patch.object(opti_app, 'initialize_models', return_value=CATALOG), \
             patch.object(opti_app.SettingsWindow, 'load_voices'):
            root = tk.Tk()
            app = opti_app.OptiiApp(root)
            try:
                root.update()
                app.open_settings()
                dialog = app.settings_window
                self.assertEqual(tuple(dialog.provider_combo['values']), ('windows',))
                self.assertIsNone(dialog.breeze_box)
                self.assertNotIn('speech.mode', dialog.vars)
                self.assertNotIn('speech.fast_all', dialog.vars)
                def descendants(widget):
                    for child in widget.winfo_children():
                        yield child
                        yield from descendants(child)
                notebooks = [widget for widget in descendants(dialog) if isinstance(widget, opti_app.ttk.Notebook)]
                titles = [book.tab(tab, 'text') for book in notebooks for tab in book.tabs()]
                self.assertNotIn('Breeze 服務參數', titles)
                dialog.vars['speech.provider'].set('breeze')
                dialog.provider_changed()
                config = core.validate_settings(dialog.collect())
                self.assertEqual(config['speech']['provider'], 'windows')
                self.assertEqual(config['speech']['device'], 'CPU')
                self.assertEqual(config['speech']['instruction'], '保留聲音設定')
                self.assertEqual(str(dialog.voice_combo['state']), 'readonly')
                self.assertEqual(saved['speech']['provider'], 'breeze')
                self.assertFalse(app.speech_controls.winfo_ismapped())
                self.assertEqual(app.speak_button.master, app.speech_controls)
            finally:
                app.quit()

    def test_theme_settings_and_tray_preserve_conversation(self):
        with patch.object(opti_app, 'load_settings', return_value=deepcopy(core.DEFAULTS)), \
             patch.object(opti_app, 'breeze_hardware_available', return_value=True), \
             patch.object(opti_app.OptiiApp, 'start_tray'), \
             patch.object(opti_app.OptiiApp, 'monitor'), \
             patch.object(opti_app, 'initialize_models', return_value=CATALOG), \
             patch.object(opti_app, 'save_settings', side_effect=lambda value: value), \
             patch.object(opti_app.SettingsWindow, 'load_voices'):
            root = tk.Tk()
            app = opti_app.OptiiApp(root)
            try:
                root.update()
                app.write('保留對話')
                app.settings['theme'] = 'light'
                app.apply_theme()
                self.assertEqual(app.transcript.cget('bg'), opti_app.LIGHT['paper'])
                app.settings['theme'] = 'dark'
                app.apply_theme()
                self.assertIn('保留對話', app.transcript.get('1.0', 'end'))
                app.open_settings()
                dialog = app.settings_window
                dialog.set_models(CATALOG)
                self.assertEqual(tuple(dialog.model_combos['text']['values']), ('gemma4:26b', 'llama3.2-vision:latest'))
                self.assertNotIn('embed:latest', dialog.model_combos['vision']['values'])
                dialog.vars['speech.provider'].set('breeze')
                dialog.provider_changed()
                self.assertEqual(dialog.vars['speech.device'].get(), 'GPU')
                self.assertEqual(str(dialog.voice_combo.cget('state')), 'disabled')
                config = core.validate_settings(dialog.collect())
                self.assertEqual(config['speech']['provider'], 'breeze')
                dialog.destroy()
                app.tray_icon = Mock(visible=True)
                with patch.object(app, 'alert') as tray_hint:
                    app.close()
                tray_hint.assert_called_once()
                root.update()
                self.assertEqual(root.state(), 'withdrawn')
                app.show()
                root.update()
                self.assertEqual(root.state(), 'normal')
                app.tray_icon = None
                with patch.object(app, 'alert') as tray_warning:
                    app.close()
                tray_warning.assert_called_once()
                root.update()
                self.assertEqual(root.state(), 'iconic')
                app.show()
                root.update()
                root.geometry('980x740')
                root.update()
                self.assertGreater(app.input.winfo_height(), 40)
                self.assertTrue(app.send_button.winfo_ismapped())
                job = core.SpeechJob()
                job.cancel()
                app.speech_job = job
                app.extra.put(('speech_ready', (job, Path('cancelled.wav'))))
                with patch.object(opti_app.winsound, 'PlaySound') as play:
                    app.poll_extra()
                    play.assert_not_called()
                    self.assertIsNone(app.speech_job)
            finally:
                app.quit()


class ModelSetupTests(unittest.TestCase):
    def test_empty_inventory_downloads_and_checks_default(self):
        job, emit = Mock(), Mock()
        with patch.object(core, 'installed_models', side_effect=[[], CATALOG]):
            result = core.initialize_models(job, emit)
        job.pull.assert_called_once_with(emit)
        self.assertEqual(result, CATALOG)

    def test_installed_models_skip_download_and_preserve_selection(self):
        job = Mock()
        config = deepcopy(core.DEFAULTS)
        config['text']['model'] = 'gemma4:26b'
        with patch.object(core, 'installed_models', return_value=CATALOG):
            core.initialize_models(job, Mock())
        job.pull.assert_not_called()
        self.assertEqual(core.select_installed_defaults(config, CATALOG), config)
        self.assertEqual(core.DEFAULTS['text']['model'], 'llama3.2-vision:latest')

    def test_first_install_downloads_default_even_when_other_models_exist(self):
        job, emit = Mock(), Mock()
        other_models = [item for item in CATALOG if item['name'] != core.DEFAULT_MODEL]
        with patch.object(core, 'installed_models', side_effect=[other_models, CATALOG]):
            self.assertEqual(core.initialize_models(job, emit, ensure_default=True), CATALOG)
        job.pull.assert_called_once_with(emit)

    def test_missing_default_does_not_silently_switch_to_user_downloaded_model(self):
        other_models = [item for item in CATALOG if item['name'] != core.DEFAULT_MODEL]
        config = core.select_installed_defaults(core.DEFAULTS, other_models)
        self.assertEqual(config['text']['model'], core.DEFAULT_MODEL)
        self.assertEqual(config['vision']['model'], core.DEFAULT_MODEL)
        chosen = deepcopy(core.DEFAULTS)
        chosen['text']['model'] = 'gemma4:26b'
        self.assertEqual(core.select_installed_defaults(chosen, other_models)['text']['model'],
                         'gemma4:26b')

    def test_connection_failure_is_not_empty_inventory(self):
        job = Mock()
        with patch.object(core, 'installed_models', side_effect=OSError('offline')):
            with self.assertRaises(OSError):
                core.initialize_models(job, Mock())
        job.pull.assert_not_called()

    def test_download_failure_and_missing_model_propagate(self):
        job = Mock()
        job.pull.side_effect = RuntimeError('disk full')
        with patch.object(core, 'installed_models', return_value=[]):
            with self.assertRaisesRegex(RuntimeError, 'disk full'):
                core.initialize_models(job, Mock())
        job.pull.side_effect = None
        with patch.object(core, 'installed_models', return_value=[]):
            with self.assertRaisesRegex(RuntimeError, '找不到'):
                core.initialize_models(job, Mock())

    def test_routing_follows_selected_model_not_chat_slot(self):
        config = deepcopy(core.DEFAULTS)
        self.assertEqual(core.route_messages(config, [], 'text', CATALOG)[1], '127.0.0.1:11435')
        config['vision']['model'] = 'gemma4:26b'
        self.assertEqual(core.route_messages(config, [], 'vision', CATALOG)[1], '127.0.0.1:11434')
        config['text']['model'] = 'custom-alias:latest'
        catalog = [{'name': 'custom-alias:latest', 'details': {'family': 'mllama'}}]
        self.assertEqual(core.route_messages(config, [], 'text', catalog)[1], '127.0.0.1:11435')

    def test_official_pull_payload_and_progress(self):
        stream = io.BytesIO(b'{"status":"pulling","total":100,"completed":50}\n{"status":"success"}\n')
        with patch.object(opti_model_worker, 'urlopen', return_value=stream) as open_request, \
             patch('sys.stdout', new_callable=io.StringIO) as stdout:
            result = opti_model_worker.main()
            self.assertIn('"completed": 50', stdout.getvalue())
        request = open_request.call_args.args[0]
        self.assertEqual(json.loads(request.data), {'model': 'llama3.2-vision', 'stream': True})
        self.assertEqual(request.full_url, 'http://127.0.0.1:11434/api/pull')
        self.assertEqual(result, 0)

    def test_custom_model_name_is_validated_and_sent_to_local_pull_api(self):
        self.assertEqual(core.validate_model_name(' hf.co/owner/model:Q4_K_M '), 'hf.co/owner/model:Q4_K_M')
        for invalid in (None, '', 'has spaces', '../escape', 'https://example.com/model'):
            with self.assertRaises(ValueError):
                core.validate_model_name(invalid)
        stream = io.BytesIO(b'{"status":"success"}\n')
        with patch.object(opti_model_worker, 'urlopen', return_value=stream) as open_request, \
             patch('sys.stdout', new_callable=io.StringIO):
            self.assertEqual(opti_model_worker.main('example/model:4b'), 0)
        self.assertEqual(json.loads(open_request.call_args.args[0].data)['model'], 'example/model:4b')

    def test_background_pull_passes_chosen_model_to_worker(self):
        process = Mock(returncode=0)
        process.stdout = io.StringIO('{"status":"success"}\n')
        process.poll.return_value = 0
        job = core.ModelDownload('example/model:4b')
        with patch.object(core.subprocess, 'Popen', return_value=process) as launch:
            job.pull(Mock())
        self.assertEqual(launch.call_args.args[0][-1], 'example/model:4b')

    def test_download_worker_refreshes_catalog_after_success(self):
        app = SimpleNamespace(extra=queue.Queue())
        job = Mock(model='example/model:4b')
        job.pull.side_effect = lambda emit: emit({'status': 'success'})
        catalog = [{'name': 'example/model:4b', 'capabilities': ['completion']}]
        with patch.object(opti_app, 'ensure_model_service') as service, \
             patch.object(opti_app, 'installed_models', return_value=catalog):
            opti_app.OptiiApp.download_catalog_model(app, job)
        service.assert_called_once_with('text', 'CPU')
        self.assertEqual(app.extra.get_nowait()[0], 'catalog_pull_progress')
        self.assertEqual(app.extra.get_nowait(), ('catalog_pull_ready', (job, catalog)))

    def test_pull_truncation_is_not_success_and_cancel_prevents_spawn(self):
        with patch.object(opti_model_worker, 'urlopen', return_value=io.BytesIO(b'{"status":"pulling"}\n')), \
             patch('sys.stdout', new_callable=io.StringIO):
            with self.assertRaisesRegex(RuntimeError, '提前結束'):
                opti_model_worker.main()
        job = core.ModelDownload()
        job.cancel()
        with patch.object(core.subprocess, 'Popen') as launch:
            with self.assertRaisesRegex(RuntimeError, '取消'):
                job.pull(Mock())
        launch.assert_not_called()


class CaptureTests(unittest.TestCase):
    def test_reverse_drag_scaling_clamping_and_tiny_click(self):
        self.assertEqual(opti_capture.crop_bounds((190, 90), (10, 5), (200, 100), (400, 200)), (20, 10, 380, 180))
        self.assertEqual(opti_capture.crop_bounds((-10, -20), (300, 150), (200, 100), (400, 200)), (0, 0, 400, 200))
        self.assertIsNone(opti_capture.crop_bounds((10, 10), (12, 90), (200, 100), (400, 200)))

    def test_region_crop_and_negative_monitor_origin(self):
        root = tk.Tk()
        root.update()
        callback = Mock()
        session = opti_capture.RegionCapture(root, callback)
        try:
            with patch.object(opti_capture, 'desktop_bounds', return_value=(-640, -100, 640, 200)), \
                 patch.object(opti_capture, 'position_overlay', wraps=opti_capture.position_overlay) as position, \
                 patch.object(opti_capture.ImageGrab, 'grab', return_value=Image.new('RGB', (1280, 400), 'red')):
                session.start()
                root.after_cancel(session.timer)
                self.assertEqual(root.state(), 'withdrawn')
                session.capture()
                self.assertEqual(session.view_size, (640, 200))
                position.assert_called_once_with(session.overlay, (-640, -100, 640, 200))
                session.press(SimpleNamespace(x=200, y=100))
                session.release(SimpleNamespace(x=20, y=10))
                image, error = callback.call_args.args
                self.assertIsNone(error)
                self.assertEqual(image.size, (360, 180))
                self.assertEqual(image.getpixel((0, 0)), (255, 0, 0))
                self.assertEqual(root.state(), 'normal')
                self.assertIsNone(session.snapshot)
        finally:
            session.cancel()
            root.destroy()

    def test_cancel_and_capture_error_restore_window(self):
        root = tk.Tk()
        root.update()
        try:
            callback = Mock()
            session = opti_capture.RegionCapture(root, callback)
            session.start()
            session.cancel()
            session.cancel()
            callback.assert_called_once_with(None, None)
            self.assertEqual(root.state(), 'normal')
            session = opti_capture.RegionCapture(root, callback)
            session.start()
            root.after_cancel(session.timer)
            with patch.object(opti_capture.ImageGrab, 'grab', side_effect=OSError('screen unavailable')):
                session.capture()
            self.assertEqual(callback.call_args.args, (None, 'screen unavailable'))
            self.assertEqual(root.state(), 'normal')
        finally:
            root.destroy()

    def test_screenshot_attaches_preserves_draft_and_cleans_only_owned_file(self):
        with ExitStack() as stack:
            stack.enter_context(patch.object(opti_app, 'load_settings', return_value=deepcopy(core.DEFAULTS)))
            stack.enter_context(patch.object(opti_app.OptiiApp, 'start_tray'))
            stack.enter_context(patch.object(opti_app.OptiiApp, 'monitor'))
            stack.enter_context(patch.object(opti_app.OptiiApp, 'connect'))
            directory = Path(stack.enter_context(tempfile.TemporaryDirectory()))
            stack.enter_context(patch.object(opti_history, 'HISTORY_DIR', directory))
            stack.enter_context(patch.object(opti_app, 'save_record', side_effect=lambda r:opti_history.save_record(r, directory)))
            stack.enter_context(patch.object(opti_app, 'list_records', side_effect=lambda:opti_history.list_records(directory)))
            root = tk.Tk()
            app = opti_app.OptiiApp(root)
            try:
                app.input.insert('1.0', '幫我看這段內容')
                app.route.set('純文字')
                app.screenshot_done(Image.new('RGB', (320, 180), 'blue'))
                path = app.pending_path
                self.assertTrue(path.is_file())
                self.assertIn('螢幕截圖', app.image_name.cget('text'))
                self.assertEqual(app.route.get(), '自動分流')
                self.assertEqual(app.input.get('1.0', 'end-1c'), '幫我看這段內容')
                app.screenshot_done(None)
                self.assertEqual(app.pending_path, path)
                self.assertTrue(path.is_file())
                with tempfile.TemporaryDirectory() as directory:
                    selected_file = Path(directory)/'user-image.png'
                    Image.new('RGB', (64, 64)).save(selected_file)
                    app.attach_image(selected_file)
                    self.assertFalse(path.exists())
                    app.clear_image()
                    self.assertTrue(selected_file.exists())
                app.screenshot_done(Image.new('RGB', (320, 180), 'blue'))
                path = app.pending_path
                app.ready = True
                app.catalog = CATALOG
                app.model_loading = False
                with patch.object(app, 'generate') as generate:
                    app.send()
                    deadline = time.monotonic()+2
                    while not generate.called and time.monotonic() < deadline:
                        time.sleep(.01)
                    self.assertTrue(generate.called)
                    self.assertTrue(generate.call_args.args[1][-1]['images'])
                    self.assertFalse(path.exists())
                self.assertEqual(app.capture_files, set())
                self.assertTrue(app.conversation['display_turns'][0]['preview'])
                saved = opti_history.load_record(app.conversation['id'], directory)
                self.assertTrue(saved['display_turns'][0]['preview'])
                self.assertEqual(saved['display_turns'][0]['attachment_kind'], 'image')
                self.assertTrue(opti_history.preview_path(saved['id'], 0).is_file())
                self.assertTrue(opti_history.attachment_path(saved['id'], 0, 'image').is_file())
                app.conversation = saved
                render_turns(app)
                self.assertEqual(len(app.visual_photos), 1)
                attachment = app.visual_turn_widgets[0]['attachment']
                self.assertTrue(attachment.bind('<ButtonRelease-1>'))
                with patch.object(opti_ui, 'ImageViewer') as viewer:
                    attachment.event_generate('<ButtonRelease-1>')
                    root.update()
                viewer.assert_called_once()
                attachment.tag_add('sel', '1.0', '1.2')
                with patch.object(opti_ui, 'ImageViewer') as viewer:
                    attachment.event_generate('<ButtonRelease-1>')
                    root.update()
                viewer.assert_not_called()
            finally:
                app.quit()




class PdfTests(unittest.TestCase):
    @staticmethod
    def text_pdf(path):
        stream = b'BT /F1 12 Tf 20 70 Td (Hello PDF document) Tj ET'
        objects = [b'<< /Type /Catalog /Pages 2 0 R >>',
                   b'<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
                   b'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 200 100] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>',
                   b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
                   b'<< /Length '+str(len(stream)).encode()+b' >>\nstream\n'+stream+b'\nendstream']
        data = b'%PDF-1.4\n'
        offsets = []
        for index, obj in enumerate(objects, 1):
            offsets.append(len(data))
            data += str(index).encode()+b' 0 obj\n'+obj+b'\nendobj\n'
        xref = len(data)
        data += b'xref\n0 6\n0000000000 65535 f \n'
        for offset in offsets:
            data += f'{offset:010d} 00000 n \n'.encode()
        data += b'trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n'+str(xref).encode()+b'\n%%EOF'
        path.write_bytes(data)

    def test_pdf_text_extraction_render_and_invalid_input(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/'文件.pdf'
            self.text_pdf(path)
            document = opti_pdf.read_pdf(path)
            self.assertIn('Hello PDF document', document['text'])
            self.assertIn('第 1 頁', document['text'])
            self.assertFalse(document['truncated'])
            self.assertEqual(opti_pdf.render_page(path, 1).size, (400, 200))
            with self.assertRaises(ValueError):
                opti_pdf.render_page(path, 2)
            with patch.object(opti_pdf, 'MAX_BYTES', 1), self.assertRaises(ValueError):
                opti_pdf.read_pdf(path)
            path.write_bytes(b'not a PDF')
            with self.assertRaises(Exception):
                opti_pdf.read_pdf(path)

    def test_scanned_pdf_and_long_document_report_limits(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/'scan.pdf'
            Image.new('RGB', (100, 200), 'blue').save(path, 'PDF')
            document = opti_pdf.read_pdf(path)
            self.assertEqual(document['text'], '')
            self.assertEqual(document['empty_pages'], [1])
            self.assertGreater(opti_pdf.render_page(path, 1).height, 0)
            document['text'] = '文字內容'*10000
            content, note = opti_pdf.pdf_prompt(document, '摘要', core.DEFAULTS['text'])
            self.assertIn('部分內容', note)
            self.assertLess(len(content), 2000)
            self.text_pdf(path)
            with patch.object(opti_pdf, 'MAX_TEXT', 12):
                self.assertTrue(opti_pdf.read_pdf(path)['truncated'])

    def test_pdf_attachment_preserves_draft_sends_context_and_cleans_page(self):
        with ExitStack() as stack:
            stack.enter_context(patch.object(opti_app, 'load_settings', return_value=deepcopy(core.DEFAULTS)))
            stack.enter_context(patch.object(opti_app.OptiiApp, 'start_tray'))
            stack.enter_context(patch.object(opti_app.OptiiApp, 'monitor'))
            stack.enter_context(patch.object(opti_app.OptiiApp, 'connect'))
            directory = stack.enter_context(tempfile.TemporaryDirectory())
            stack.enter_context(patch.object(opti_history, 'HISTORY_DIR', Path(directory)/'history'))
            stack.enter_context(patch.object(opti_app, 'save_record',
                side_effect=lambda record: opti_history.save_record(record, Path(directory)/'history')))
            stack.enter_context(patch.object(opti_app, 'list_records',
                side_effect=lambda: opti_history.list_records(Path(directory)/'history')))
            path = Path(directory)/'test.pdf'
            self.text_pdf(path)
            document = opti_pdf.read_pdf(path)
            root = tk.Tk()
            app = opti_app.OptiiApp(root)
            try:
                self.assertIn('OptiChat', root.title())
                app.input.insert('1.0', '幫我摘要')
                app.attach_pdf(document)
                self.assertEqual(app.input.get('1.0', 'end-1c'), '幫我摘要')
                self.assertEqual(app.route.get(), '純文字')
                app.ready, app.model_loading, app.catalog = True, False, CATALOG
                with patch.object(app, 'generate'):
                    app.send()
                self.assertIn('Hello PDF document', app.turn['content'])
                self.assertIn('幫我摘要', app.turn['content'])
                self.assertIsNone(app.pending_document)
                self.assertTrue(app.conversation['display_turns'][0]['attachment'].startswith('PDF：'))
                self.assertEqual(app.conversation['display_turns'][0]['attachment_kind'], 'pdf')
                self.assertNotIn('preview', app.conversation['display_turns'][0])
                stored_pdf = opti_history.attachment_path(app.conversation['id'], 0, 'pdf')
                self.assertEqual(stored_pdf.read_bytes(), path.read_bytes())
                attachment = app.visual_turn_widgets[0]['attachment']
                self.assertTrue(attachment.bind('<Double-Button-1>'))
                with patch.object(opti_ui.os, 'startfile') as open_file:
                    opti_ui.open_attachment(app, app.conversation['display_turns'][0], 0)
                open_file.assert_called_once_with(str(stored_pdf))
                def widgets(parent):
                    for child in parent.winfo_children():
                        yield child
                        yield from widgets(child)
                pdf_icons = [widget for widget in widgets(app.visual_body) if isinstance(widget, tk.Canvas)
                             and any(widget.type(item) == 'text' and widget.itemcget(item, 'text') == 'PDF'
                                     for item in widget.find_all())]
                self.assertEqual(len(pdf_icons), 1)
                app.set_busy(False)
                app.attach_pdf(document, opti_pdf.render_page(path, 1), 1)
                image_path = app.pending_path
                self.assertEqual(app.route.get(), '自動分流')
                self.assertTrue(image_path.is_file())
                self.assertIn('第 1', app.prepare_turn('辨識')['content'])
                with patch.object(app, 'generate'):
                    app.send()
                self.assertTrue(app.conversation['display_turns'][-1]['attachment'].startswith('PDF：'))
                self.assertEqual(app.conversation['display_turns'][-1]['attachment_kind'], 'pdf')
                self.assertNotIn('preview', app.conversation['display_turns'][-1])
                self.assertEqual(opti_history.attachment_path(app.conversation['id'], 1, 'pdf').read_bytes(),
                                 path.read_bytes())
                self.assertFalse(image_path.exists())
                self.assertTrue(path.is_file())
            finally:
                app.quit()

    def test_drop_pdf_into_chat_and_restore_renamed_conversation(self):
        with ExitStack() as stack:
            stack.enter_context(patch.object(opti_app, 'load_settings', return_value=deepcopy(core.DEFAULTS)))
            stack.enter_context(patch.object(opti_app.OptiiApp, 'start_tray'))
            stack.enter_context(patch.object(opti_app.OptiiApp, 'monitor'))
            stack.enter_context(patch.object(opti_app.OptiiApp, 'connect'))
            directory = Path(stack.enter_context(tempfile.TemporaryDirectory()))
            store = directory/'history'
            stack.enter_context(patch.object(opti_history, 'HISTORY_DIR', store))
            stack.enter_context(patch.object(opti_app, 'save_record', side_effect=lambda r:opti_history.save_record(r, store)))
            stack.enter_context(patch.object(opti_app, 'list_records', side_effect=lambda:opti_history.list_records(store)))
            stack.enter_context(patch.object(opti_app, 'load_record', side_effect=lambda i:opti_history.load_record(i, store)))
            pdf = directory/'PDF 文件 with spaces.pdf'
            self.text_pdf(pdf)
            root = tk.Tk()
            app = opti_app.OptiiApp(root)
            try:
                self.assertTrue(root.tk.call('package', 'present', 'tkdnd'))
                app.input.insert('1.0', '請摘要')
                event = SimpleNamespace(data=root.tk.call('list', str(pdf)))
                app.on_drop(event)
                for _ in range(100):
                    root.update()
                    if app.pending_document:
                        break
                    time.sleep(.01)
                self.assertIsNotNone(app.pending_document)
                self.assertEqual(app.input.get('1.0', 'end-1c'), '請摘要')
                self.assertEqual(app.pending_document['path'], pdf)
                app.ready, app.model_loading, app.catalog = True, False, CATALOG
                with patch.object(app, 'generate'):
                    app.send()
                self.assertRegex(app.conversation['title'], r'^\d{4}-\d\d-\d\d \d\d:\d\d$')
                self.assertEqual(len(opti_history.list_records(store)), 1)
                app.events.put(('token', '已閱讀並整理重點。'))
                app.events.put(('complete', 'stop'))
                app.events.put(('finished', False))
                app.poll()
                self.assertEqual(app.conversation['display_turns'][0]['answer'], '已閱讀並整理重點。')
                self.assertEqual(opti_history.list_records(store)[0]['display_turns'][0]['answer'], '已閱讀並整理重點。')
                app.new_chat()
                self.assertEqual(app.conversation_list.size(), 1)
                app.conversation_list.selection_set(0)
                app.select_conversation()
                self.assertIn('請摘要', app.transcript.get('1.0', 'end-1c'))
                with patch.object(app, 'prompt', return_value='我的報告'):
                    app.rename_conversation()
                self.assertEqual(opti_history.list_records(store)[0]['title'], '我的報告')
            finally:
                app.quit()


if __name__ == '__main__':
    unittest.main()
